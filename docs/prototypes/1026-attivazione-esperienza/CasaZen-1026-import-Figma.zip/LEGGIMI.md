# CasaZen · Attivazione immobili #1026

Il pacchetto crea due pagine in Figma Design, **1026 · Percorsi desktop** e **1026 · Percorsi mobile**. Ogni pagina contiene la mappa, sette tracce, schermate modificabili e collegamenti per la presentazione.

## Come importare

1. Estrai lo ZIP in una cartella. Lascia `manifest.json` e `code.js` nella stessa cartella.
2. Apri **Figma Desktop** e un nuovo file **Figma Design** su cui hai permessi di modifica.
3. Nel menu Figma scegli **Plugins → Development → Import plugin from manifest…** e seleziona `manifest.json`.
4. Apri **Plugins → Development → CasaZen · Attivazione immobili #1026**. Il plugin seleziona **00 · Mappa dei percorsi**.
5. Premi **Presenta**. Usa **Prova il percorso** per partire dall’ingresso o **Vedi i passaggi** per entrare da un punto preciso. Per provare il mobile, apri la pagina **1026 · Percorsi mobile**, seleziona **00 · Mappa mobile** e premi **Presenta**.

Se Figma Desktop richiede un ID di sviluppo generato dal tuo account, usa **Plugins → Development → New plugin…**, scegli Figma Design e salva il plugin in una nuova cartella. Sostituisci il file indicato come `main` nel suo manifest con il `code.js` di questo pacchetto, conservando il manifest generato. Avvia il plugin dal menu **Development**.

## Cosa puoi provare

Per seguire la richiesta automatica dei dati parti da **Completare e pubblicare una scheda**. Il percorso porta dai controlli dopo l’importazione a Da fare, quindi al campo da correggere.

- In Figma le azioni fanno avanzare da un fotogramma all’altro. Le varianti dei moduli hanno pulsanti dedicati.
- Nell’HTML interattivo puoi anche inserire dati dimostrativi, tornare indietro, sbagliare un campo, conservare i filtri e seguire il cambio di stato tra host e staff.
- Il plugin usa i token del frontend CasaZen e il marchio esistente. Genera solo le pagine degli scenari nel file in cui lo esegui. Richieste alle API e suggerimenti AI sono simulati.

[Documentazione Figma per i plugin locali](https://developers.figma.com/docs/plugins/plugin-quickstart-guide/) · [Issue #1026](https://github.com/casazen/backend/issues/1026)
